﻿<?php
/**
 * Plugin Name:  CS WPGraphQL Auto-Bridge
 * Plugin URI:   https://cortinastudio.com.gt
 * Description:  Expone automaticamente TODOS los CPTs y meta fields de JetEngine
 *               a WPGraphQL. Sin configuracion manual. Sin codigo hardcodeado.
 *               Instala, activa, listo. Funciona en cualquier sitio JetEngine + WPGraphQL.
 * Version:      2.0.0
 * Author:       Cortina Studio
 * License:      Private
 *
 * COMO FUNCIONA
 * 1. Lee la lista de CPTs que JetEngine guardo en wp_options (jet_engine_cpts).
 * 2. Inyecta show_in_graphql + nombres GraphQL en cada CPT al momento del registro.
 * 3. Lee los Meta Boxes de JetEngine (post type jet-engine-meta-boxes).
 * 4. Registra cada campo como field de GraphQL en su tipo correspondiente.
 * 5. Repeaters se devuelven como JSON string para que Next.js los parsee.
 *
 * PANEL DE ESTADO: Settings -> WPGraphQL Bridge
 * CLIENTE NUEVO = instalar este mismo plugin sin tocar codigo.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CSB_VERSION', '2.0.0' );


// ======================================================
// BLOQUE 1 - EXPONER CPTs A WPGRAPHQL
// Lee jet_engine_cpts de wp_options e inyecta
// show_in_graphql en cada CPT registrado por JetEngine.
// ======================================================

add_filter( 'register_post_type_args', 'csb_expose_jetengine_cpt', 10, 2 );

function csb_expose_jetengine_cpt( array $args, string $post_type ): array {
	$jet_cpts = csb_get_jetengine_cpts();

	if ( ! isset( $jet_cpts[ $post_type ] ) ) {
		return $args;
	}

	$cpt_data = $jet_cpts[ $post_type ];
	$labels   = (array) ( $cpt_data['labels'] ?? [] );

	$singular_label = $labels['singular_name'] ?? $post_type;
	$plural_label   = $labels['name']          ?? ( $post_type . 's' );

	$args['show_in_graphql']     = true;
	$args['graphql_single_name'] = csb_label_to_graphql_name( $singular_label );
	$args['graphql_plural_name'] = csb_label_to_graphql_name( $plural_label );

	return $args;
}


// ======================================================
// BLOQUE 2 - REGISTRAR META FIELDS EN WPGRAPHQL
// Lee los Meta Boxes de JetEngine y registra cada campo
// en el tipo GraphQL del CPT correspondiente.
// ======================================================

add_action( 'graphql_register_types', 'csb_register_all_jetengine_fields' );

function csb_register_all_jetengine_fields(): void {
	$field_map = csb_build_field_map();

	foreach ( $field_map as $post_type => $fields ) {
		$pt_obj = get_post_type_object( $post_type );

		if ( ! $pt_obj || empty( $pt_obj->graphql_single_name ) ) {
			continue;
		}

		$gql_type = ucfirst( $pt_obj->graphql_single_name );

		foreach ( $fields as $meta_key => $field_config ) {
			$gql_name    = csb_meta_key_to_camel( $meta_key );
			$field_type  = $field_config['type'] ?? 'text';
			$is_repeater = in_array( $field_type, [ 'repeater', 'group', 'media-gallery' ], true );

			register_graphql_field( $gql_type, $gql_name, [
				'type'        => 'String',
				'description' => sprintf(
					'[JetEngine %s] meta_key: %s',
					$is_repeater ? 'repeater->JSON' : $field_type,
					$meta_key
				),
				'resolve' => $is_repeater
					? csb_make_repeater_resolver( $meta_key )
					: csb_make_scalar_resolver( $meta_key ),
			] );
		}
	}
}


// ======================================================
// BLOQUE 3 - LEER DATOS INTERNOS DE JETENGINE
// ======================================================

/**
 * Devuelve todos los CPTs de JetEngine indexados por slug.
 * JetEngine guarda esta lista en wp_options bajo 'jet_engine_cpts'.
 */
function csb_get_jetengine_cpts(): array {
	static $cache = null;

	if ( $cache === null ) {
		$stored = get_option( 'jet_engine_cpts', [] );
		$cache  = [];

		foreach ( (array) $stored as $cpt ) {
			$slug = $cpt['slug'] ?? '';
			if ( $slug ) {
				$cache[ $slug ] = $cpt;
			}
		}
	}

	return $cache;
}

/**
 * Construye mapa [ post_type_slug => [ meta_key => field_config ] ]
 * leyendo todos los Meta Boxes de JetEngine.
 */
function csb_build_field_map(): array {
	static $cache = null;

	if ( $cache !== null ) {
		return $cache;
	}

	$cache = [];

	$boxes = get_posts( [
		'post_type'              => 'jet-engine-meta-boxes',
		'posts_per_page'         => -1,
		'post_status'            => 'publish',
		'update_post_meta_cache' => true,
		'update_post_term_cache' => false,
		'no_found_rows'          => true,
	] );

	foreach ( $boxes as $box ) {
		$fields     = get_post_meta( $box->ID, '_fields', true );
		$post_types = csb_detect_box_post_types( $box->ID );

		if ( empty( $fields ) || ! is_array( $fields ) || empty( $post_types ) ) {
			continue;
		}

		foreach ( $post_types as $pt ) {
			if ( ! isset( $cache[ $pt ] ) ) {
				$cache[ $pt ] = [];
			}

			foreach ( $fields as $field ) {
				$name = $field['name'] ?? '';
				if ( empty( $name ) ) {
					continue;
				}
				// Primer meta box gana si hay campo duplicado
				if ( ! isset( $cache[ $pt ][ $name ] ) ) {
					$cache[ $pt ][ $name ] = $field;
				}
			}
		}
	}

	return $cache;
}

/**
 * Detecta a que post types aplica un Meta Box de JetEngine.
 * JetEngine cambia como guarda esto entre versiones, por eso
 * probamos 4 enfoques en orden de confiabilidad.
 *
 * @return string[]
 */
function csb_detect_box_post_types( int $box_id ): array {

	// Enfoque A: _args['allowed_post_type'] - JetEngine 3.x
	$args = get_post_meta( $box_id, '_args', true );
	if ( ! empty( $args['allowed_post_type'] ) && is_array( $args['allowed_post_type'] ) ) {
		return array_values( array_filter( $args['allowed_post_type'] ) );
	}

	// Enfoque B: meta directo 'allowed_post_type'
	$direct = get_post_meta( $box_id, 'allowed_post_type', true );
	if ( ! empty( $direct ) ) {
		return is_array( $direct )
			? array_values( array_filter( $direct ) )
			: [ $direct ];
	}

	// Enfoque C: _conditions [{type:'post_type', value:'...'}]
	$conditions = get_post_meta( $box_id, '_conditions', true );
	if ( ! empty( $conditions ) && is_array( $conditions ) ) {
		$found = [];
		foreach ( $conditions as $cond ) {
			if (
				isset( $cond['type'], $cond['value'] ) &&
				$cond['type'] === 'post_type' &&
				! empty( $cond['value'] )
			) {
				$found[] = $cond['value'];
			}
		}
		if ( ! empty( $found ) ) {
			return $found;
		}
	}

	// Enfoque D: escanea todo el post_meta buscando claves con 'post_type'
	$all_meta = get_post_meta( $box_id );
	foreach ( $all_meta as $key => $values ) {
		if ( strpos( $key, 'post_type' ) === false ) {
			continue;
		}
		$val = maybe_unserialize( $values[0] ?? '' );
		if ( is_array( $val ) && ! empty( $val ) ) {
			return array_values( array_filter( $val ) );
		}
		if ( is_string( $val ) && ! empty( $val ) ) {
			return [ $val ];
		}
	}

	return [];
}


// ======================================================
// BLOQUE 4 - RESOLVERS
// ======================================================

function csb_make_scalar_resolver( string $meta_key ): Closure {
	return static function ( $post ) use ( $meta_key ): ?string {
		$value = get_post_meta( $post->databaseId, $meta_key, true );

		if ( $value === '' || $value === false || $value === null ) {
			return null;
		}

		return is_scalar( $value ) ? (string) $value : null;
	};
}

function csb_make_repeater_resolver( string $meta_key ): Closure {
	return static function ( $post ) use ( $meta_key ): ?string {
		$value = get_post_meta( $post->databaseId, $meta_key, true );

		if ( empty( $value ) ) {
			return null;
		}

		if ( is_array( $value ) ) {
			return wp_json_encode( $value ) ?: null;
		}

		if ( is_string( $value ) ) {
			return $value;
		}

		return null;
	};
}


// ======================================================
// BLOQUE 5 - UTILIDADES
// ======================================================

/**
 * Convierte una label legible en nombre GraphQL camelCase.
 * "Proyectos Destacados" -> "proyectosDestacados"
 * "home-singleton"       -> "homeSingleton"
 */
function csb_label_to_graphql_name( string $label ): string {
	$label = strtolower( trim( $label ) );
	$label = preg_replace( '/[^a-z0-9\s_\-]/', '', $label );
	$parts = preg_split( '/[\s_\-]+/', $label );
	$parts = array_values( array_filter( (array) $parts ) );

	if ( empty( $parts ) ) {
		return 'cpt';
	}

	$first = array_shift( $parts );
	return $first . implode( '', array_map( 'ucfirst', $parts ) );
}

/**
 * Convierte meta_key a camelCase para GraphQL.
 * "video_poster" -> "videoPoster"
 * "hero-title"   -> "heroTitle"
 */
function csb_meta_key_to_camel( string $meta_key ): string {
	$parts = preg_split( '/[_\-]+/', strtolower( $meta_key ) );
	$parts = array_values( array_filter( (array) $parts ) );

	if ( empty( $parts ) ) {
		return $meta_key;
	}

	$first = array_shift( $parts );
	return $first . implode( '', array_map( 'ucfirst', $parts ) );
}


// ======================================================
// BLOQUE 6 - PANEL DE ADMIN
// Settings -> WPGraphQL Bridge
// ======================================================

add_action( 'admin_menu', 'csb_add_admin_menu' );

function csb_add_admin_menu(): void {
	add_options_page(
		'WPGraphQL Auto-Bridge',
		'WPGraphQL Bridge',
		'manage_options',
		'csb-status',
		'csb_render_status_page'
	);
}

function csb_render_status_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$jet_cpts  = csb_get_jetengine_cpts();
	$field_map = csb_build_field_map();
	?>
	<div class="wrap">
		<h1>WPGraphQL Auto-Bridge <small style="font-size:14px;color:#888">v<?php echo esc_html( CSB_VERSION ); ?></small></h1>
		<p>Auto-descubre y expone CPTs y meta fields de JetEngine a WPGraphQL sin configuracion manual.</p>

		<h2>CPTs de JetEngine detectados</h2>

		<?php if ( empty( $jet_cpts ) ) : ?>
			<div class="notice notice-error inline">
				<p>No se encontraron CPTs en <code>jet_engine_cpts</code>. Verifica que JetEngine este activo y tenga CPTs creados.</p>
			</div>
		<?php else : ?>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr>
					<th>Post Type Slug</th>
					<th>GraphQL Single</th>
					<th>GraphQL Plural</th>
					<th>Estado</th>
				</tr></thead>
				<tbody>
				<?php foreach ( $jet_cpts as $slug => $cpt ) :
					$labels   = (array) ( $cpt['labels'] ?? [] );
					$singular = csb_label_to_graphql_name( $labels['singular_name'] ?? $slug );
					$plural   = csb_label_to_graphql_name( $labels['name'] ?? ( $slug . 's' ) );
					$pt_obj   = get_post_type_object( $slug );
					$exposed  = $pt_obj && ! empty( $pt_obj->graphql_single_name );
					?>
					<tr>
						<td><code><?php echo esc_html( $slug ); ?></code></td>
						<td><code><?php echo esc_html( $singular ); ?></code></td>
						<td><code><?php echo esc_html( $plural ); ?></code></td>
						<td>
							<?php if ( $exposed ) : ?>
								Expuesto &mdash; tipo GraphQL: <code><?php echo esc_html( ucfirst( $pt_obj->graphql_single_name ) ); ?></code>
							<?php else : ?>
								No expuesto &mdash; el slug no coincidio con el filtro
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h2 style="margin-top:2rem">Meta fields descubiertos por CPT</h2>

		<?php if ( empty( $field_map ) ) : ?>
			<div class="notice notice-warning inline">
				<p>No se encontraron meta fields. Los Meta Boxes de JetEngine pueden no tener el post type asignado, o el enfoque de deteccion no coincide con esta version de JetEngine.</p>
			</div>
			<?php echo csb_debug_meta_boxes_html(); ?>
		<?php else : ?>
			<?php foreach ( $field_map as $pt => $fields ) :
				$pt_obj   = get_post_type_object( $pt );
				$gql_type = $pt_obj ? ucfirst( $pt_obj->graphql_single_name ?? '' ) : '(CPT no expuesto)';
				?>
				<h3>
					<code><?php echo esc_html( $pt ); ?></code>
					<small style="font-weight:normal;color:#555">&rarr; tipo GraphQL: <code><?php echo esc_html( $gql_type ); ?></code></small>
				</h3>
				<table class="widefat striped" style="max-width:900px;margin-bottom:1.5rem">
					<thead><tr>
						<th>meta_key</th>
						<th>GraphQL field</th>
						<th>Tipo JetEngine</th>
					</tr></thead>
					<tbody>
					<?php foreach ( $fields as $meta_key => $field ) :
						$gql_name   = csb_meta_key_to_camel( $meta_key );
						$field_type = $field['type'] ?? 'text';
						$is_rep     = in_array( $field_type, [ 'repeater', 'group', 'media-gallery' ], true );
						?>
						<tr>
							<td><code><?php echo esc_html( $meta_key ); ?></code></td>
							<td><code><?php echo esc_html( $gql_name ); ?></code></td>
							<td><?php echo esc_html( $field_type ); ?><?php if ( $is_rep ) echo ' &mdash; devuelve JSON string'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endforeach; ?>
		<?php endif; ?>

		<h2 style="margin-top:2rem">Query de verificacion</h2>
		<p>Pega esto en <strong>GraphQL &rarr; GraphiQL IDE</strong>:</p>
		<pre style="background:#f0f0f0;padding:16px;max-width:700px;overflow:auto;font-size:13px"><?php
			echo esc_html( csb_generate_test_query( $field_map, $jet_cpts ) );
		?></pre>
	</div>
	<?php
}

function csb_debug_meta_boxes_html(): string {
	$boxes = get_posts( [
		'post_type'      => 'jet-engine-meta-boxes',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
	] );

	if ( empty( $boxes ) ) {
		return '<p>No se encontraron posts de tipo <code>jet-engine-meta-boxes</code>. Crea al menos un Meta Box en JetEngine y asignalo a un CPT.</p>';
	}

	$out  = '<details style="margin-top:1rem"><summary style="cursor:pointer;font-weight:600">';
	$out .= 'Debug: ' . count( $boxes ) . ' Meta Box(es) encontrados &mdash; clic para ver estructura interna</summary>';
	$out .= '<p style="color:#555;margin:8px 0">Estos datos muestran como JetEngine guarda la asignacion de post types en tu version. Enviame esta informacion si los fields no se detectan.</p>';
	$out .= '<pre style="background:#f8f8f8;padding:16px;max-width:900px;overflow:auto;font-size:12px">';

	foreach ( $boxes as $box ) {
		$all_meta = get_post_meta( $box->ID );
		$out     .= "\n=== Box ID: {$box->ID} | \"{$box->post_title}\" ===\n";

		foreach ( $all_meta as $key => $values ) {
			$val = maybe_unserialize( $values[0] ?? '' );

			if ( $key === '_fields' && is_array( $val ) ) {
				$names = array_column( $val, 'name' );
				$out  .= esc_html( $key ) . ' => [fields: ' . implode( ', ', $names ) . "]\n";
				continue;
			}

			$out .= esc_html( $key ) . ' => ' . esc_html( print_r( $val, true ) ) . "\n";
		}
	}

	$out .= '</pre></details>';
	return $out;
}

function csb_generate_test_query( array $field_map, array $jet_cpts ): string {
	if ( empty( $jet_cpts ) ) {
		return '# No se encontraron CPTs de JetEngine.';
	}

	$query = "{\n";

	foreach ( $jet_cpts as $slug => $cpt ) {
		$labels = (array) ( $cpt['labels'] ?? [] );
		$plural = csb_label_to_graphql_name( $labels['name'] ?? ( $slug . 's' ) );

		$query .= "  {$plural} {\n    nodes {\n      id\n      title\n";

		if ( ! empty( $field_map[ $slug ] ) ) {
			foreach ( array_slice( array_keys( $field_map[ $slug ] ), 0, 3 ) as $meta_key ) {
				$query .= '      ' . csb_meta_key_to_camel( $meta_key ) . "\n";
			}
		}

		$query .= "    }\n  }\n";
	}

	return $query . '}';
}
