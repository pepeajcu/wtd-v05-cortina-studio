<?php
/**
 * Plugin Name:  Cortina Studio — WPGraphQL Bridge
 * Plugin URI:   https://cortinastudio.com.gt
 * Description:  Expone los CPTs de JetEngine (Home, Proyecto) y todos sus
 *               meta fields a WPGraphQL para la integración headless con Next.js.
 *               No requiere configuración — instala y activa.
 * Version:      1.0.0
 * Author:       Cortina Studio
 * License:      Private
 *
 * ──────────────────────────────────────────────────────────────────────────────
 * INSTALACIÓN
 * ──────────────────────────────────────────────────────────────────────────────
 * 1. Sube esta carpeta (cortinastudio-wpgraphql-bridge/) a:
 *      wp-content/plugins/
 * 2. En el admin de WordPress: Plugins → Activar "Cortina Studio — WPGraphQL Bridge"
 * 3. Ve a GraphQL → GraphiQL IDE y corre la query de verificación de abajo.
 *
 * REQUISITOS PREVIOS
 * ──────────────────────────────────────────────────────────────────────────────
 * - Plugin WPGraphQL activo
 * - Plugin JetEngine activo con los CPTs "home" y "proyecto" ya creados
 *
 * IMPORTANTE: SLUGS DE LOS CPTs
 * ──────────────────────────────────────────────────────────────────────────────
 * Las constantes CSE_CPT_HOME y CSE_CPT_PROYECTO deben coincidir EXACTAMENTE
 * con el "Post Type Slug" que definiste en JetEngine al crear cada CPT.
 * Para verificarlo: JetEngine → Custom Post Types → Edit → campo "Post Type Slug".
 *
 * QUERY DE VERIFICACIÓN (pega en GraphiQL IDE)
 * ──────────────────────────────────────────────────────────────────────────────
 * {
 *   proyectos { nodes { id title video platform spaceType } }
 *   homes { nodes { id heroTitle heroEyebrow } }
 * }
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ──────────────────────────────────────────────────────────────────────────────
// CONFIGURACIÓN — ajusta estos valores si los slugs de tus CPTs son diferentes
// ──────────────────────────────────────────────────────────────────────────────

define( 'CSE_CPT_HOME',     'home-singleton' );      // Post Type Slug del CPT Home (singleton)
define( 'CSE_CPT_PROYECTO', 'proyectos' );  // Post Type Slug del CPT Proyecto


// ──────────────────────────────────────────────────────────────────────────────
// 1. EXPONER CPTs A WPGRAPHQL
//    JetEngine no añade show_in_graphql al registrar sus CPTs.
//    Este filtro lo inyecta en el momento del registro.
// ──────────────────────────────────────────────────────────────────────────────

add_filter( 'register_post_type_args', 'cse_expose_cpts_to_graphql', 10, 2 );

function cse_expose_cpts_to_graphql( array $args, string $post_type ): array {
	$map = [
		CSE_CPT_HOME     => [ 'single' => 'home',     'plural' => 'homes'     ],
		CSE_CPT_PROYECTO => [ 'single' => 'proyecto',  'plural' => 'proyectos' ],
	];

	if ( isset( $map[ $post_type ] ) ) {
		$args['show_in_graphql']     = true;
		$args['graphql_single_name'] = $map[ $post_type ]['single'];
		$args['graphql_plural_name'] = $map[ $post_type ]['plural'];
	}

	return $args;
}


// ──────────────────────────────────────────────────────────────────────────────
// 2. REGISTRAR META FIELDS EN EL SCHEMA DE WPGRAPHQL
//    Cada campo se expone con su nombre camelCase (coincide con wp-config.json)
//    y resuelve desde su meta_key snake_case en WordPress.
//    Repeaters de JetEngine → se serializan como JSON String.
//    El fetcher de Next.js (Fase 3) los parsea con JSON.parse().
// ──────────────────────────────────────────────────────────────────────────────

add_action( 'graphql_register_types', 'cse_register_all_graphql_fields' );

function cse_register_all_graphql_fields(): void {
	cse_register_proyecto_fields();
	cse_register_home_fields();
}


// ── CPT: Proyecto ─────────────────────────────────────────────────────────────

function cse_register_proyecto_fields(): void {
	// [ graphql_field_name => meta_key_en_wordpress ]
	$fields = [
		'video'           => 'video',
		'videoPoster'     => 'video_poster',
		'videoAlt'        => 'video_alt',
		'platform'        => 'platform',
		'originalUrl'     => 'original_url',
		'spaceType'       => 'space_type',
		'clientProblem'   => 'client_problem',
		'solution'        => 'solution',
		'benefit'         => 'benefit',
		'solutionSummary' => 'solution_summary',
	];

	foreach ( $fields as $gql_name => $meta_key ) {
		register_graphql_field( 'Proyecto', $gql_name, [
			'type'        => 'String',
			'description' => "JetEngine field: {$meta_key}",
			'resolve'     => cse_make_scalar_resolver( $meta_key ),
		] );
	}
}


// ── CPT: Home (singleton) ─────────────────────────────────────────────────────
// Los repeaters (problems_cards, process_steps, etc.) se devuelven como JSON
// string para que Next.js los parsee. Los escalares se devuelven directamente.

function cse_register_home_fields(): void {
	// Campos escalares: [ graphql_field_name => meta_key ]
	$scalar_fields = [
		// Hero
		'heroEyebrow'      => 'hero_eyebrow',
		'heroTitle'        => 'hero_title',
		'heroSubtitle'     => 'hero_subtitle',
		'heroImage'        => 'hero_image',
		'heroImageCaption' => 'hero_image_caption',
		'heroCtaLabel'     => 'hero_cta_label',
		'heroCtaMessage'   => 'hero_cta_message',
		// Problems
		'problemsEyebrow'  => 'problems_eyebrow',
		'problemsTitle'    => 'problems_title',
		'problemsSubtitle' => 'problems_subtitle',
		// Reels
		'reelsEyebrow'          => 'reels_eyebrow',
		'reelsTitle'            => 'reels_title',
		'reelsSubtitle'         => 'reels_subtitle',
		'reelsCtaText'          => 'reels_cta_text',
		'reelsCtaButton'        => 'reels_cta_button',
		'reelsWhatsappMessage'  => 'reels_whatsapp_message',
		// Process
		'processEyebrow'        => 'process_eyebrow',
		'processTitlePrefixM'   => 'process_title_prefix_m',
		'processTitlePrefixF'   => 'process_title_prefix_f',
		'processTitleSuffix'    => 'process_title_suffix',
		'processSubtitle'       => 'process_subtitle',
		'processCtaLabel'       => 'process_cta_label',
	];

	foreach ( $scalar_fields as $gql_name => $meta_key ) {
		register_graphql_field( 'Home', $gql_name, [
			'type'        => 'String',
			'description' => "JetEngine field: {$meta_key}",
			'resolve'     => cse_make_scalar_resolver( $meta_key ),
		] );
	}

	// Repeaters → JSON String
	// problemsCards    : array de { icon, title, description }
	// reelsSelected    : array de IDs de proyectos destacados
	// processRotatingWords : array de { word, gender }
	// processSteps     : array de { icon, title, description }
	$repeater_fields = [
		'problemsCards'        => 'problems_cards',
		'reelsSelected'        => 'reels_selected',
		'processRotatingWords' => 'process_rotating_words',
		'processSteps'         => 'process_steps',
	];

	foreach ( $repeater_fields as $gql_name => $meta_key ) {
		register_graphql_field( 'Home', $gql_name, [
			'type'        => 'String',
			'description' => "JetEngine repeater (JSON): {$meta_key}",
			'resolve'     => cse_make_repeater_resolver( $meta_key ),
		] );
	}
}


// ──────────────────────────────────────────────────────────────────────────────
// HELPERS — closures reutilizables para resolver meta fields
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Devuelve un resolver para campos escalares (string, number, url).
 * Retorna null si el campo está vacío para no enviar strings vacíos al frontend.
 */
function cse_make_scalar_resolver( string $meta_key ): Closure {
	return static function ( $post ) use ( $meta_key ): ?string {
		$value = get_post_meta( $post->databaseId, $meta_key, true );
		if ( $value === '' || $value === false ) {
			return null;
		}
		return is_scalar( $value ) ? (string) $value : null;
	};
}

/**
 * Devuelve un resolver para repeaters de JetEngine.
 * JetEngine guarda los repeaters como arrays PHP serializados.
 * Este resolver los convierte a JSON string para que Next.js los parsee.
 */
function cse_make_repeater_resolver( string $meta_key ): Closure {
	return static function ( $post ) use ( $meta_key ): ?string {
		$value = get_post_meta( $post->databaseId, $meta_key, true );
		if ( empty( $value ) ) {
			return null;
		}
		if ( is_array( $value ) ) {
			return wp_json_encode( $value ) ?: null;
		}
		// Si ya es un string JSON (guardado así por alguna versión de JetEngine)
		if ( is_string( $value ) ) {
			return $value;
		}
		return null;
	};
}
